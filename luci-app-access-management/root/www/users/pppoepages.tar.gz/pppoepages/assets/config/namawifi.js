document.write('.')
//Sesuaikan
//Jangan Menghapus kode scriptnya