document.write('Mutiara-Wrt & Alpha.net')
//Sesuaikan
//Jangan Menghapus kode scriptnya