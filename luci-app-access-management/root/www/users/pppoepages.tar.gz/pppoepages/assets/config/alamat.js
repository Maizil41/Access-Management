document.write('RT anu/RW anu <br>Kecamatan anu<br>Kabupaten anu - Jawa anu')
//Sesuaikan, Jika ingin menggunakan karakter "enter" gunakan kode <br>
//Jangan Menghapus kode scriptnya
