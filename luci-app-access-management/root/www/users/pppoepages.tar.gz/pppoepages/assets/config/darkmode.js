window.darkmodefunction = "manual"; // "auto" atau "manual"
//Sesuaikan
//Jangan Menghapus kode scriptnya