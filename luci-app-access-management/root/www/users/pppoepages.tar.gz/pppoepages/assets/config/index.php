<?php
header("HTTP/1.1 301 Moved Permanently");
echo "<meta http-equiv='refresh' content='0;url=/' />";
?>