<?php
/*
 * ------------------------------------------------------------
 * License : (GPL-2.0) GNU General Public License Version 2
 * Created & developed by @Taufik <https://t.me/taufik_n_a>
 * © 2025 AlphaNetwork by @Taufik
 * ------------------------------------------------------------
*/

function getHsname()
{
    require 'config/mysqli_db.php';
    $hostname = '';

    $res1 = $conn->query("SELECT hsname1 FROM print_config LIMIT 1");
    if ($res1 && $row = $res1->fetch_assoc()) {
        $hostname .= $row['hsname1'];
    }

    $res2 = $conn->query("SELECT hsname2 FROM print_config LIMIT 1");
    if ($res2 && $row = $res2->fetch_assoc()) {
        $hostname .= $row['hsname2'];
    }

    $res1->close();
    $res2->close();
    $conn->close();
    return $hostname;
}

$hsname = getHsname();