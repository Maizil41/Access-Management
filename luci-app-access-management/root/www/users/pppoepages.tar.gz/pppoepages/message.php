<?php
/*
 * ------------------------------------------------------------------------------------------------------------------------
 * Created by @Maizil https://t.me/maizil41
 * © 2024 Mutiara-Net By @Maizil
 *
 * Modifications for PPPoE Status Page (RadMonv2) by @Taufik <https://t.me/taufik_n_a>
 * ------------------------------------------------------------------------------------------------------------------------
 * License : (GPL-2.0) GNU General Public License Version 2
 * © 2025 AlphaNetwork All rights reserved.
 * ------------------------------------------------------------------------------------------------------------------------
*/

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if ($path !== "/ppp/message")
{
    header("HTTP/1.1 301 Moved Permanently");
    echo "<meta http-equiv='refresh' content='0;url=/' />";
    exit();
}

$admin_number = trim(shell_exec("uci get whatsapp-bot.@whatsapp_bot[0].admin_number"));
if (strpos($admin_number, '0') === 0) {
    $admin_number = '62' . substr($admin_number, 1);
}

if (!$admin_number) {
    header("Location: /ppp/contact?message=" . urlencode("⚠️ Kirim pesan gagal karena nomor admin belum disetting."));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['needs'], $_POST['name'], $_POST['whatsapp'], $_POST['ip'], $_POST['mac'], $_POST['message'])) {
        $needs = htmlspecialchars(trim($_POST['needs']));
        $name = htmlspecialchars(trim($_POST['name']));
        $number = htmlspecialchars(trim($_POST['whatsapp']));
        $ipaddress = htmlspecialchars(trim($_POST['ip']));
        $macaddress = htmlspecialchars(trim($_POST['mac']));
        $message = htmlspecialchars(trim($_POST['message']));
        
        $hari = array(
          'Sunday' => 'Minggu',
          'Monday' => 'Senin',
          'Tuesday' => 'Selasa',
          'Wednesday' => 'Rabu',
          'Thursday' => 'Kamis',
          'Friday' => 'Jumat',
          'Saturday' => 'Sabtu'
        );

        $bulan = array(
          1 => 'Januari',
          2 => 'Februari',
          3 => 'Maret',
          4 => 'April',
          5 => 'Mei',
          6 => 'Juni',
          7 => 'Juli',
          8 => 'Agustus',
          9 => 'September',
          10 => 'Oktober',
          11 => 'November',
          12 => 'Desember'
        );

        $now = time();
        $tanggal = date('j', $now);
        $bulan_num = date('n', $now);
        $tahun = date('Y', $now);
        $jam = date('H:i:s', $now);
        $hari_ind = $hari[date('l', $now)];
        $bulan_ind = $bulan[$bulan_num];

        $hasil_tanggal = "$hari_ind, $tanggal $bulan_ind $tahun $jam";

        if (!preg_match('/^\d{10,15}$/', $number)) {
            header("Location: /ppp/contact?message=⚠️ Nomor tidak valid.");
            exit();
        }

        $send_message = "╔════════════════════╗\n"
                . "             ℹ  *PESAN PPPoE*\n"
                . "╚════════════════════╝\n"
                . "$hasil_tanggal\n"
                . "══════════════════════\n"
                . "Keperluan: _*$needs*_\n"
                . "Nama : _*$name*_\n"
                . "Nomor: _*$number*_\n"
                . "══════════════════════\n"
                . "IP Addr: _*$ipaddress*_\n"
                . "Mac Addr: _*$macaddress*_\n"
                . "Pesan :\n"
                . "_*$message*_\n"
                . "╔════════════════════╗\n"
                . "          Powered By *Mutiara-Wrt*\n"
                . "╚════════════════════╝";

        $url = 'http://localhost:3000/send-message';
        $data = [
            'to' => $admin_number,
            'message' => $send_message,
        ];

        $options = [
            'http' => [
                'header'  => "Content-Type: application/json\r\n",
                'method'  => 'POST',
                'content' => json_encode($data),
            ],
        ];

        $context  = stream_context_create($options);
        $result = @file_get_contents($url, false, $context);

        if ($result === FALSE) {
            header("Location: /ppp/contact?message=❌ Kirim pesan gagal.");
            exit();
        } else {
            header("Location: /ppp/contact?message=✅ Pesan terkirim.");
            exit();
        }
    } else {
        header("Location: /ppp/contact?message=⚠️ Data tidak valid.");
        exit();
    }
} else {
    header("Location: /ppp/contact?message=⚠️ Metode tidak valid.");
    exit();
}
?>