<?php

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if ($path === "/ppp/home" || $path === "/ppp/package" || $path === "/ppp/faq" || $path === "/ppp/contact") {
    require 'db_config.php';

    $conn = new mysqli($db_config['servername'], $db_config['username'], $db_config['password'], $db_config['dbname']);

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }
}
?>