<?php

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if ($path === "/ppp/home" || $path === "/ppp/package" || $path === "/ppp/faq" || $path === "/ppp/contact") {
    $db_config = [
        'servername' => getConfigValue('DB_SERVER', '127.0.0.1'),
        'username' => getConfigValue('DB_USER', 'radmon'),
        'password' => getConfigValue('DB_PASS', 'radmon'),
        'dbname' => getConfigValue('DB_NAME', 'radmon')
    ];
}
?>
