<?php
/*
 * ------------------------------------------------------------
 * License : (GPL-2.0) GNU General Public License Version 2
 * Created & developed by @Taufik <https://t.me/taufik_n_a>
 * © 2025 AlphaNetwork by @Taufik
 * ------------------------------------------------------------
*/
header("Content-Type: application/json");

function getUserIp()
{
    $candidates = [
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_CLIENT_IP',
        'REMOTE_ADDR'
    ];

    foreach ($candidates as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = trim(explode(',', $_SERVER[$key])[0]);
            return $ip;
        }
    }

    return "127.0.0.1";
}

function getGatewayFromUserIp()
{
    $user_ip = getUserIp();

    if (!filter_var($user_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return "127.0.0.1";
    }

    $route = @shell_exec("ip route get " . escapeshellarg($user_ip) . " 2>/dev/null");

    if (!$route) {
        return "127.0.0.1";
    }

    if (preg_match('/via ([0-9.]+)/', $route, $matches)) {
        return $matches[1];
    }

    if (preg_match('/src ([0-9.]+)/', $route, $matches)) {
        return $matches[1];
    }

    return $user_ip;
}

$gateway_ip = getGatewayFromUserIp();
$input = file_get_contents("php://input");
$servers = json_decode($input, true) ?? [];

array_unshift($servers, ["name" => "Gateway ($gateway_ip)", "host" => $gateway_ip]);

function pingServer($host)
{
    $os = PHP_OS_FAMILY;
    if ($os === 'Windows') {
        $command = "ping -n 1 -w 1000 " . escapeshellarg($host);
    } else {
        $command = "ping -c 1 -W 1 " . escapeshellarg($host);
    }

    exec($command, $output, $status);
    $outputText = implode(" ", $output);

    if ($status === 0) {
        if ($os === 'Windows') {
            preg_match('/time[=<]([\d]+)ms/', $outputText, $matches);
        } else {
            preg_match('/time=([\d.]+) ms/', $outputText, $matches);
        }

        return [
            "status" => "🟢 Online",
            "ping"   => isset($matches[1]) ? $matches[1] . " ms" : "N/A"
        ];
    } else {
        return [
            "status" => "🔴 Offline",
            "ping"   => "N/A"
        ];
    }
}

$result = [];
foreach ($servers as $server)
{
    $status = pingServer($server["host"]);
    $result[] = ["name" => $server["name"], "status" => $status["status"], "ping" => $status["ping"]];
}

echo json_encode($result);
exit;
?>