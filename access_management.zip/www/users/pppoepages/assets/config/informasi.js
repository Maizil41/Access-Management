document.write('Berlangganan WIFI rumah mulai 100RIBU.... Silahkan hubungi kami.')
//Sesuaikan
//Jangan Menghapus kode scriptnya