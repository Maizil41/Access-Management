document.write('AlphaWireless.net')
//Sesuaikan
//Jangan Menghapus kode scriptnya