export const servers = [
    { name: "Cloudflare", host: "cloudflare.com" },
    { name: "Google", host: "google.com" },
    { name: "YouTube", host: "youtube.com" },
    { name: "TikTok", host: "tiktok.com" },
    { name: "X (Twitter)", host: "x.com" },
    { name: "Telegram", host: "api.telegram.org" },
    { name: "Instagram", host: "instagram.com" },
    { name: "Facebook", host: "facebook.com" },
    { name: "WhatsApp", host: "whatsapp.com" },
    { name: "Mobile Legends", host: "m.mobilelegends.com" },
    { name: "Free Fire", host: "ff.garena.com" },
    { name: "PUBG", host: "pubg.com" },
    { name: "Honor of Kings", host: "honorofkings.com" },
    { name: "Arena of Valor", host: "arenaofvalor.com" },
    { name: "ROBLOX", host: "roblox.com" }
];
//Sesuaikan name dan host 
//Jangan Menghapus kode scriptnya