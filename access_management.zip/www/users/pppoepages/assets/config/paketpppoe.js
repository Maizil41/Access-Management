const paketPPPoE = [
    {
        nama: "HEMAT",
        harga: 100000,
        keterangan: "Pilihan terbaik untuk kebutuhan sehari-hari! Lancar untuk browsing, media sosial, dan streaming ringan."
    },
    {
        nama: "SUPER",
        harga: 150000,
        keterangan: "Streaming HD tanpa buffering dan gaming online lebih stabil. Nikmati internet cepat dengan harga terjangkau!"
    },
    {
        nama: "ULTRA",
        harga: 200000,
        keterangan: "Internet super cepat untuk keluarga! Streaming 4K, gaming online, dan video call lancar tanpa hambatan."
    },
    {
        nama: "MAX",
        harga: 250000,
        keterangan: "Kecepatan maksimal untuk bisnis dan rumah dengan banyak perangkat! Stabil dan cepat sepanjang hari."
    }
];
//Sesuaikan
//Jangan Menghapus kode scriptnya