document.write('Mutiara-Wrt')
//Sesuaikan
//Jangan Menghapus kode scriptnya